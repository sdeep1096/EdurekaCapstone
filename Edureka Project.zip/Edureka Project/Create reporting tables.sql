create table dbo.SalesTrend(
    [Date] date,
    [Year] int,
    [Month] varchar(20),
    [Country] varchar(200),
    [State] varchar(200),
    [ProductCategory] varchar(200),
    [SubCategory] varchar(200),
    [TotalQuantity] int,
    [TotalRevenue] decimal(19,2)
);

select * from SalesTrend;
select * from SalesFact;


insert into dbo.SalesTrend(
    [Date],
    [Year],
    [Month],
    [Country],


    [Country],
    [State],
    [ProductCategory],
    [SubCategory],
    [TotalQuantity],
    [TotalRevenue]
)
select [Date],[Year],[Month],[Country],[State],[ProductCategory],[SubCategory],SUM([Quantity]),SUM([Revenue])
From dbo.SalesFact
group by [Date],[Year],[Month],[Country],[State],[ProductCategory],[SubCategory];



create table dbo.CustomerBehavior(
    [CustomerAge] int,
    [CustomerGender] char(1),
    [Country] varchar(200),
    [State] varchar(200),
    [ProductCategory] varchar(200),
    [SubCategory] varchar(200),
    [TotalQuantity] int,
    [TotalRevenue] decimal(19,2)
);


select * from CustomerBehavior;

insert into CustomerBehavior(
    [CustomerAge],
    [CustomerGender],
    [Country],
    [State],
    [ProductCategory],
    [SubCategory],
    [TotalQuantity],
    [TotalRevenue]
)
select [CustomerAge],[CustomerGender],[Country],[State],[ProductCategory],[SubCategory],SUM([Quantity]),SUM([Revenue])
from SalesFact
group by [CustomerAge],[CustomerGender],[Country],[State],[ProductCategory],[SubCategory];