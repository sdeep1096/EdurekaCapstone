SELECT
[index],
[Date],
[Year],
[Month],
CustomerAge,
CustomerGender,
Country,
[State],
ProductCategory,
ProductSubCategory,
Quantity,
UnitCost,
UnitPrice,
Cost,
Revenue,
EventProcessedUtcTime as CreDate,
EventProcessedUtcTime as UpdDate
INTO [salesSQLPool]
FROM [salesdata];
